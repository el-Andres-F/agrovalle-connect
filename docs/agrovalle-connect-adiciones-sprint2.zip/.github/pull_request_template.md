## Descripción
<!-- Qué cambia y por qué. Enlazar la tarjeta del tablero o la HU. -->

## Lista de verificación
- [ ] La CI (`build-and-test`) está en verde.
- [ ] Checkstyle sin advertencias.
- [ ] Pruebas nuevas o actualizadas (patrón AAA) y cobertura JaCoCo ≥ 60 %.
- [ ] No se incluyen credenciales en el código.
- [ ] Revisado y aprobado por un integrante distinto al autor.
